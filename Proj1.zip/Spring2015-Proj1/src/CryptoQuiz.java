
import java.util.Scanner;

public class CryptoQuiz {

	private static int 
	NUM_BITS1, 
	NUM_BITS2, 
	NUM_BITS3, 
	NUM_BITS4;

	private static String 
	CRYPT1,
	CRYPT2,
	CRYPT3, 
	CRYPT4;

	private static String 
	promptInitialChoice, 
	promptSelectBITs, 
	promptWhichSystemPart1,
	promptWhichSystemPart2, 
	promptSelectSystem, 
	promptHowManyBITsPart1,
	promptHowManyBITsPart2,
	feedbackInvalidChoice, 
	feedbackCorrect,
	feedbackIncorrect;


	//CODE ABOVE HERE IS GIVEN TO YOU - DO NOT ALTER IT


	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);


		//Initialize the quiz Q&A values, storing the values in the
		//  variables that were defined for you earlier in the code above.

		NUM_BITS1 = 64; 
		NUM_BITS2 = 128;
		NUM_BITS3 = 168; 
		NUM_BITS4 = 768;

		CRYPT1 = "Blowfish";
		CRYPT2 = "Rijndael";
		CRYPT3 = "TripleDES";
		CRYPT4 = "RSA";

		//Ask what language they would like to use.

		System.out.println("1) English   2) Espanol:");
		int language = myScanner.nextInt();

		//Based on the language selected above, set prompt and feedback 
		//  variables in that language.


		if (language == 1 ) {

			promptInitialChoice = "Enter 1 to guess a crypto system, 2 to guess how many BITs:";
			promptSelectBITs = "Select number of BITs:"; 
			promptWhichSystemPart1 = "Which crypto system uses ";
			promptWhichSystemPart2 = "BITs?";
			promptSelectSystem = "Select a crypto system: ";
			promptHowManyBITsPart1 = "How many BITs are used in a ";
			promptHowManyBITsPart2 = "system?";
			feedbackInvalidChoice = "Invalid choice.";
			feedbackCorrect = "Correct!";
			feedbackIncorrect = "Incorrect!";

		}


		if (language == 2 ) {

			promptInitialChoice = " Presione el numero 1 para adivinar un sistema de codificacion criptografica, 2 para adivinar la cantidad de BITS:"; 
			promptSelectBITs = "Seleccione el numero de BITs:";
			promptWhichSystemPart1 = "Que sistema de codificacion criptografica utiliza ";
			promptWhichSystemPart2 = "BITs?";
			promptSelectSystem = "Seleccione un sistema de codificacion criptografica:";
			promptHowManyBITsPart1 = "Cuantos BITs son utilizados en un sistema ";
			promptHowManyBITsPart2 = "?";
			feedbackInvalidChoice = "Opcion invalida.";
			feedbackCorrect = "Correcto!";
			feedbackIncorrect = "Incorrecto!";

		}


		//Perform the quiz!

		/*
		 * self-note
		 * 1st condition - language
		 * 2nd conditions - actual quiz
		 * 
		 * above has defined answers depending on language so the next part just code
		 * the actual quiz's format
		 * 
		 * if for what system
		 * if for how many bits
		 *  
		 */
		int questionChoice;
		System.out.print(promptInitialChoice);
		questionChoice = myScanner.nextInt();

		//guess system after choosing bits
		if (questionChoice == 1){
			System.out.print(promptSelectBITs);
			int numBits;
			numBits= myScanner.nextInt();

			if (numBits!=NUM_BITS1 && numBits!=NUM_BITS2 && numBits!=NUM_BITS3 && numBits!=NUM_BITS4)
				System.out.println (feedbackInvalidChoice);

			else{
				System.out.print (promptWhichSystemPart1 + numBits + " " + promptWhichSystemPart2);
				String BITsAnswer = myScanner.next ();
				if (numBits == NUM_BITS1 && BITsAnswer.equalsIgnoreCase(CRYPT1))
					System.out.print(feedbackCorrect);
				else if (numBits == NUM_BITS2 && BITsAnswer.equalsIgnoreCase(CRYPT2))
					System.out.print(feedbackCorrect);
				else if (numBits == NUM_BITS3 && BITsAnswer.equalsIgnoreCase(CRYPT3))
					System.out.print(feedbackCorrect);
				else if (numBits == NUM_BITS4 && BITsAnswer.equalsIgnoreCase(CRYPT4))
					System.out.print(feedbackCorrect);
				else
					System.out.print (feedbackIncorrect);
			}
		}

		//guess bits after choosing system
		if (questionChoice==2){
			System.out.print(promptSelectSystem);
			String Crypt = myScanner.next ();

			if (!Crypt.equals (CRYPT1) && !Crypt.equals (CRYPT2) && !Crypt.equals (CRYPT3) && !Crypt.equals (CRYPT4))
				System.out.println (feedbackInvalidChoice);	

			else{
				System.out.print (promptHowManyBITsPart1 + Crypt + " " + promptHowManyBITsPart2);
				int CryptAnswer= myScanner.nextInt ();
				if (Crypt.equalsIgnoreCase(CRYPT1) && CryptAnswer == (NUM_BITS1))
					System.out.print (feedbackCorrect);
				else if (Crypt.equalsIgnoreCase (CRYPT2) && CryptAnswer == (NUM_BITS2))
					System.out.print (feedbackCorrect);
				else if (Crypt.equalsIgnoreCase(CRYPT3) && CryptAnswer == (NUM_BITS3))
					System.out.print (feedbackCorrect);
				else if (Crypt.equalsIgnoreCase (CRYPT4) && CryptAnswer == (NUM_BITS4))
					System.out.print (feedbackCorrect);
				else
					System.out.print (feedbackIncorrect);
			}

		}
		myScanner.close();
	}

}
